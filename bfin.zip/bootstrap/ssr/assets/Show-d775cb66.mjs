import { j as jsxs, a as jsx } from "../ssr.mjs";
import { Head, router } from "@inertiajs/react";
import { A as Authenticated } from "./AuthenticatedLayout-4665b554.mjs";
import Swal from "sweetalert2";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "react";
import "./ApplicationLogo-f5319d5c.mjs";
import "@headlessui/react";
function Show(props) {
  const { financing, auth } = props;
  const financingFields = [
    { label: "Nombre", value: financing.name },
    { label: "Presupuesto", value: financing.budget },
    { label: "Tipo", value: financing.type },
    { label: "País", value: financing.country.name },
    { label: "Región", value: financing.region },
    { label: "Fecha de Inicio", value: financing.start_date },
    { label: "Fecha de Fin", value: financing.end_date },
    { label: "Institución", value: financing.institution },
    { label: "Resumen", value: financing.summary },
    { label: "CRL", value: financing.crl.name },
    { label: "TRL", value: financing.trl.name },
    {
      label: "OCDE",
      value: financing.ocde.map((item) => item.code).join(", ")
    },
    {
      label: "ODS",
      value: financing.ods.map((item) => item.name).join(", ")
    },
    {
      label: "Estado",
      value: financing.status === 1 ? "Vigente" : "No Vigente"
    },
    { label: "Ir al sitio", name: "link", value: financing.link },
    {
      label: "Archivo",
      name: "file_path",
      value: financing.file_path
    },
    { label: "Creación del registro", value: financing.created_at },
    { label: "Otros", value: financing.others }
  ];
  const handleDelete = async (id) => {
    Swal.fire({
      title: "¿Estás seguro?",
      text: "No serás capaz de revertir la acción",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Si"
    }).then((result) => {
      if (result.isConfirmed) {
        router.delete(`/financing/${id}`, {
          onSuccess: () => {
            Swal.fire({
              title: "Registro Eliminado",
              text: "Se elimino el registro",
              icon: "success"
            });
          },
          onError: () => {
            return Swal.fire({
              icon: "Error",
              title: "Oops...",
              text: "Algo salió mal"
            });
          }
        });
      }
    });
  };
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      auth: props.auth,
      errors: props.errors,
      header: /* @__PURE__ */ jsx("h2", { className: "font-semibold text-xl text-gray-800 leading-tight", children: "Informacion Financiamiento" }),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Registro financiamiento" }),
        /* @__PURE__ */ jsx("div", { className: "py-6 mx-3", children: /* @__PURE__ */ jsxs("div", { className: "max-w-7xl mx-auto sm:px-6 lg:px-8", children: [
          /* @__PURE__ */ jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4 mt-6", children: financingFields.map((field, i) => /* @__PURE__ */ jsxs("div", { children: [
            /* @__PURE__ */ jsx("h2", { className: "text-lg font-medium text-gray-900", children: field.label }),
            field.name === "file_path" && /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-gray-600", children: /* @__PURE__ */ jsx(
              "a",
              {
                href: field.value,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "text-blue-500",
                children: "Descargar"
              }
            ) }),
            field.name === "link" ? /* @__PURE__ */ jsx(
              "a",
              {
                href: field.value,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "mt-1 text-sm text-blue-500",
                children: field.label
              }
            ) : Array.isArray(field.value) ? /* @__PURE__ */ jsx("ul", { className: "mt-1 text-sm text-gray-600", children: field.value.map((item) => /* @__PURE__ */ jsx("li", { children: item.name || item.description }, item.id)) }) : field.name !== "file_path" && /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-gray-600", children: field.value })
          ] }, i)) }),
          auth.user.role_id == 1 && /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => handleDelete(financing.id),
              className: "mt-4 px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600",
              children: "Eliminar"
            }
          )
        ] }) })
      ]
    }
  );
}
export {
  Show as default
};
