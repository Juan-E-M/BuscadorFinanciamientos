import { j as jsxs, a as jsx } from "../ssr.mjs";
import { A as Authenticated } from "./AuthenticatedLayout-4665b554.mjs";
import { Head, Link } from "@inertiajs/react";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "react";
import "./ApplicationLogo-f5319d5c.mjs";
import "@headlessui/react";
function Index(props) {
  const users = props.users;
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      auth: props.auth,
      errors: props.errors,
      header: /* @__PURE__ */ jsx("h2", { className: "font-semibold text-xl text-gray-800 leading-tight", children: "Usuarios" }),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Usuarios" }),
        /* @__PURE__ */ jsx("div", { className: "p-6 mt-12 max-w-7xl mx-auto sm:px-6 lg:px-8 overflow-hidden rounded-lg shadow-md", children: /* @__PURE__ */ jsxs("table", { className: "w-full shadow", children: [
          /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "border-b bg-gray-50 text-left text-xs font-semibold uppercase tracking-wide text-gray-400", children: [
            /* @__PURE__ */ jsx("th", { className: "border-b-2 border-gray-200 bg-gray-100 px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-600", children: "Nombre" }),
            /* @__PURE__ */ jsx("th", { className: "border-b-2 border-gray-200 bg-gray-100 px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-600", children: "Apellidos" }),
            /* @__PURE__ */ jsx("th", { className: "border-b-2 border-gray-200 bg-gray-100 px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-600 hidden sm:table-cell", children: "Email" }),
            /* @__PURE__ */ jsx("th", { className: "border-b-2 border-gray-200 bg-gray-100 px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-600 hidden sm:table-cell", children: "Telefono" }),
            /* @__PURE__ */ jsx("th", { className: "border-b-2 border-gray-200 bg-gray-100 px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-600", children: "Más" })
          ] }) }),
          /* @__PURE__ */ jsx("tbody", { children: users.map((user) => /* @__PURE__ */ jsxs("tr", { className: "text-gray-700", children: [
            /* @__PURE__ */ jsx("td", { className: "border-b border-gray-200 bg-white px-5 py-5 text-sm", children: /* @__PURE__ */ jsx("p", { className: "text-gray-900 whitespace-no-wrap", children: user.name }) }),
            /* @__PURE__ */ jsx("td", { className: "border-b border-gray-200 bg-white px-5 py-5 text-sm", children: /* @__PURE__ */ jsx("p", { className: "text-gray-900 whitespace-no-wrap", children: user.lastname }) }),
            /* @__PURE__ */ jsx("td", { className: "border-b border-gray-200 bg-white px-5 py-5 text-sm hidden sm:table-cell", children: /* @__PURE__ */ jsx("p", { className: "text-gray-900 whitespace-no-wrap", children: user.email }) }),
            /* @__PURE__ */ jsx("td", { className: "border-b border-gray-200 bg-white px-5 py-5 text-sm hidden sm:table-cell", children: /* @__PURE__ */ jsx("p", { className: "text-gray-900 whitespace-no-wrap", children: user.phone_number }) }),
            /* @__PURE__ */ jsx("td", { className: "border-b border-gray-200 bg-white px-5 py-5 text-sm", children: /* @__PURE__ */ jsx(
              Link,
              {
                href: `/users/${user.id}`,
                className: "text-blue-600 underline whitespace-no-wrap hover:text-gray-900",
                children: "Information"
              }
            ) })
          ] }, user.id)) })
        ] }) })
      ]
    }
  );
}
export {
  Index as default
};
