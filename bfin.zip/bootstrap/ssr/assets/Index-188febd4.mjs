import { j as jsxs, a as jsx } from "../ssr.mjs";
import { Head, Link } from "@inertiajs/react";
import { useState, useRef, useEffect } from "react";
import { A as Authenticated } from "./AuthenticatedLayout-4665b554.mjs";
import ExcelReportButton from "./ExcelReportButton-9e536227.mjs";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "./ApplicationLogo-f5319d5c.mjs";
import "@headlessui/react";
import "exceljs";
const defaultValues = {
  ocde: "",
  ods: "",
  trl: "",
  crl: "",
  type: "",
  country: "",
  institution: "",
  status: ""
};
function Index(props) {
  const { financings, crlOptions, trlOptions, ocdes, odss, countries } = props;
  const [crls, setCrls] = useState(crlOptions);
  const [trls, setTrls] = useState(trlOptions);
  const [odsOptions, setOdsOptions] = useState(odss);
  const [ocdeOptions, setOcdeOptions] = useState(ocdes);
  const [searchFilters, setSearchFilters] = useState({ ...defaultValues });
  const crlSelect = useRef();
  const trlSelect = useRef();
  const odsSelect = useRef();
  const ocdeSelect = useRef();
  const handleClean = () => {
    setSearchFilters({ ...defaultValues });
    setData(financings);
  };
  const handleSearch = (e) => {
    setSearchFilters({ ...searchFilters, [e.target.name]: e.target.value });
  };
  let data = financings.filter((financing) => {
    const ocdeMatch = !searchFilters.ocde ? true : financing.ocde.some(
      (ocde) => ocde.id == searchFilters.ocde
    );
    const odsMatch = !searchFilters.ods ? true : financing.ods.some((ods) => ods.id == searchFilters.ods);
    const trlMatch = !searchFilters.trl ? true : financing.trl_id == searchFilters.trl;
    const crlMatch = !searchFilters.crl ? true : financing.crl_id == searchFilters.crl;
    const institutionMatch = searchFilters.institution === "" ? true : financing.institution.toLowerCase().includes(searchFilters.institution.toLowerCase());
    const statusMatch = searchFilters.status === "" ? true : financing.status == searchFilters.status;
    const countryMatch = !searchFilters.country ? true : financing.country_id == searchFilters.country;
    const typeMatch = !searchFilters.type ? true : financing.type == searchFilters.type;
    return ocdeMatch && odsMatch && trlMatch && crlMatch && countryMatch && typeMatch && institutionMatch && statusMatch;
  });
  const truncateText = (text, maxLength) => {
    if (text.length > maxLength) {
      return text.slice(0, maxLength - 3) + "...";
    }
    return text;
  };
  useEffect(() => {
    const handleResize = () => {
      if (crlSelect.current) {
        const selectWidth1 = crlSelect.current.offsetWidth;
        const chars1 = Math.floor(selectWidth1 / 6.9);
        const arrayConNuevaClave = crls.map((objeto) => ({
          ...objeto,
          truncatedText: truncateText(
            objeto.name + " - " + objeto.description,
            chars1
          )
        }));
        setCrls(arrayConNuevaClave);
      }
      if (trlSelect.current) {
        const selectWidth2 = trlSelect.current.offsetWidth;
        const chars2 = Math.floor(selectWidth2 / 6.9);
        const arrayConNuevaClave1 = trls.map((objeto) => ({
          ...objeto,
          truncatedText: truncateText(
            objeto.name + " - " + objeto.description,
            chars2
          )
        }));
        setTrls(arrayConNuevaClave1);
      }
      if (odsSelect.current) {
        const selectWidth3 = odsSelect.current.offsetWidth;
        const chars3 = Math.floor(selectWidth3 / 6.9);
        const arrayConNuevaClave3 = odsOptions.map((objeto) => ({
          ...objeto,
          truncatedText: truncateText(
            objeto.name + " - " + objeto.description,
            chars3
          )
        }));
        setOdsOptions(arrayConNuevaClave3);
      }
      if (ocdeSelect.current) {
        const selectWidth4 = ocdeSelect.current.offsetWidth;
        const chars4 = Math.floor(selectWidth4 / 6.9);
        const arrayConNuevaClave4 = ocdeOptions.map((objeto) => ({
          ...objeto,
          truncatedText: truncateText(
            objeto.code + " - " + objeto.name,
            chars4
          )
        }));
        setOcdeOptions(arrayConNuevaClave4);
      }
    };
    window.addEventListener("resize", handleResize);
    handleResize();
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      auth: props.auth,
      errors: props.errors,
      header: /* @__PURE__ */ jsx("h2", { className: "font-semibold text-xl text-gray-800 leading-tight", children: "Buscador" }),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Registro financiamiento" }),
        /* @__PURE__ */ jsx("div", { className: "py-6 mx-3", children: /* @__PURE__ */ jsxs("div", { className: "max-w-7xl mx-auto sm:px-6 lg:px-8", children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-4 inline-flex w-full overflow-hidden rounded-lg bg-white shadow-md", children: [
            /* @__PURE__ */ jsx("div", { className: "flex items-center justify-center bg-blue-500", children: /* @__PURE__ */ jsx(
              "svg",
              {
                className: "h-6 w-6 fill-current text-white",
                viewBox: "0 0 40 40",
                xmlns: "http://www.w3.org/2000/svg",
                children: /* @__PURE__ */ jsx("path", { d: "M20 3.33331C10.8 3.33331 3.33337 10.8 3.33337 20C3.33337 29.2 10.8 36.6666 20 36.6666C29.2 36.6666 36.6667 29.2 36.6667 20C36.6667 10.8 29.2 3.33331 20 3.33331ZM21.6667 28.3333H18.3334V25H21.6667V28.3333ZM21.6667 21.6666H18.3334V11.6666H21.6667V21.6666Z" })
              }
            ) }),
            /* @__PURE__ */ jsx("div", { className: "px-4 flex-grow", children: /* @__PURE__ */ jsxs("div", { className: "border-b border-gray-900/10 pb-2", children: [
              /* @__PURE__ */ jsxs("div", { className: "mt-4 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-4", children: [
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx(
                    "label",
                    {
                      htmlFor: "crl",
                      className: "block text-sm font-medium leading-6 text-gray-900",
                      children: "CRL"
                    }
                  ),
                  /* @__PURE__ */ jsx("div", { className: "mt-2", children: /* @__PURE__ */ jsxs(
                    "select",
                    {
                      required: true,
                      onChange: handleSearch,
                      value: searchFilters.crl,
                      ref: crlSelect,
                      id: "crl",
                      name: "crl",
                      className: "block w-full rounded-md border-0  py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300  focus:ring-indigo-600 sm:text-sm",
                      children: [
                        /* @__PURE__ */ jsx("option", { value: "", children: "Seleccionar todos" }),
                        crls.map((item) => /* @__PURE__ */ jsx(
                          "option",
                          {
                            value: item.id,
                            children: item.truncatedText
                          },
                          item.id
                        ))
                      ]
                    }
                  ) })
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx(
                    "label",
                    {
                      htmlFor: "trl",
                      className: "block text-sm font-medium leading-6 text-gray-900",
                      children: "TRL"
                    }
                  ),
                  /* @__PURE__ */ jsx("div", { className: "mt-2", children: /* @__PURE__ */ jsxs(
                    "select",
                    {
                      required: true,
                      value: searchFilters.trl,
                      ref: trlSelect,
                      id: "trl",
                      name: "trl",
                      onChange: handleSearch,
                      className: "block w-full rounded-md border-0  py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300  focus:ring-indigo-600 sm:text-sm",
                      children: [
                        /* @__PURE__ */ jsx("option", { value: "", children: "Seleccionar todos" }),
                        trls.map((item) => /* @__PURE__ */ jsx(
                          "option",
                          {
                            value: item.id,
                            children: item.truncatedText
                          },
                          item.id
                        ))
                      ]
                    }
                  ) })
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx(
                    "label",
                    {
                      htmlFor: "ocde",
                      className: "block text-sm font-medium leading-6 text-gray-900",
                      children: "OCDE"
                    }
                  ),
                  /* @__PURE__ */ jsx("div", { className: "mt-2", children: /* @__PURE__ */ jsxs(
                    "select",
                    {
                      required: true,
                      value: searchFilters.ocde,
                      ref: ocdeSelect,
                      id: "ocde",
                      name: "ocde",
                      onChange: handleSearch,
                      className: "block w-full rounded-md border-0  py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300  focus:ring-indigo-600 sm:text-sm",
                      children: [
                        /* @__PURE__ */ jsx("option", { value: "", children: "Seleccionar todos" }),
                        ocdeOptions.map((item) => /* @__PURE__ */ jsx(
                          "option",
                          {
                            value: item.id,
                            children: item.truncatedText
                          },
                          item.id
                        ))
                      ]
                    }
                  ) })
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx(
                    "label",
                    {
                      htmlFor: "ods",
                      className: "block text-sm font-medium leading-6 text-gray-900",
                      children: "ODS"
                    }
                  ),
                  /* @__PURE__ */ jsx("div", { className: "mt-2", children: /* @__PURE__ */ jsxs(
                    "select",
                    {
                      required: true,
                      value: searchFilters.ods,
                      ref: odsSelect,
                      id: "ods",
                      name: "ods",
                      onChange: handleSearch,
                      className: "block w-full rounded-md border-0  py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300  focus:ring-indigo-600 sm:text-sm",
                      children: [
                        /* @__PURE__ */ jsx("option", { value: "", children: "Seleccionar todos" }),
                        odsOptions.map((item) => /* @__PURE__ */ jsx(
                          "option",
                          {
                            value: item.id,
                            children: item.truncatedText
                          },
                          item.id
                        ))
                      ]
                    }
                  ) })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "mt-4 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-4", children: [
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("label", { className: "block text-sm font-medium leading-6 text-gray-900", children: "Estado" }),
                  /* @__PURE__ */ jsx("div", { className: "mt-2", children: /* @__PURE__ */ jsxs(
                    "select",
                    {
                      value: searchFilters.status,
                      onChange: handleSearch,
                      className: "block w-full rounded-md border-0  py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300  focus:ring-indigo-600 sm:text-sm",
                      name: "status",
                      children: [
                        /* @__PURE__ */ jsx("option", { value: "", children: "Todos" }),
                        /* @__PURE__ */ jsx("option", { value: 1, children: "Vigente" }),
                        /* @__PURE__ */ jsx("option", { value: 0, children: "No Vigente" })
                      ]
                    }
                  ) })
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx(
                    "label",
                    {
                      htmlFor: "type",
                      className: "block text-sm font-medium leading-6 text-gray-900",
                      children: "Tipo de Financiamiento"
                    }
                  ),
                  /* @__PURE__ */ jsx("div", { className: "mt-2", children: /* @__PURE__ */ jsxs(
                    "select",
                    {
                      required: true,
                      onChange: handleSearch,
                      value: searchFilters.type,
                      id: "type",
                      name: "type",
                      className: "block w-full rounded-md border-0  py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300  focus:ring-indigo-600 sm:text-sm",
                      children: [
                        /* @__PURE__ */ jsx("option", { value: "", children: "Seleccionar todos" }),
                        /* @__PURE__ */ jsx("option", { value: "No reembolsables (RNR)", children: "No reembolsables (RNR)" }),
                        /* @__PURE__ */ jsx("option", { value: "Con intereses", children: "Con intereses" }),
                        /* @__PURE__ */ jsx("option", { value: "Sin intereses", children: "Sin intereses" }),
                        /* @__PURE__ */ jsx("option", { value: "No definido", children: "No definido" })
                      ]
                    }
                  ) })
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx(
                    "label",
                    {
                      htmlFor: "country",
                      className: "block text-sm font-medium leading-6 text-gray-900",
                      children: "País"
                    }
                  ),
                  /* @__PURE__ */ jsx("div", { className: "mt-2", children: /* @__PURE__ */ jsxs(
                    "select",
                    {
                      required: true,
                      onChange: handleSearch,
                      value: searchFilters.country,
                      id: "country",
                      name: "country",
                      className: "block w-full rounded-md border-0  py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300  focus:ring-indigo-600 sm:text-sm",
                      children: [
                        /* @__PURE__ */ jsx("option", { value: "", children: "Seleccionar todos" }),
                        countries.map((item) => /* @__PURE__ */ jsx(
                          "option",
                          {
                            value: item.id,
                            children: item.name
                          },
                          item.id
                        ))
                      ]
                    }
                  ) })
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx(
                    "label",
                    {
                      htmlFor: "institution",
                      className: "block text-sm font-medium leading-6 text-gray-900",
                      children: "Institución"
                    }
                  ),
                  /* @__PURE__ */ jsx("div", { className: "mt-2", children: /* @__PURE__ */ jsx(
                    "input",
                    {
                      required: true,
                      value: searchFilters.institution,
                      type: "text",
                      id: "institution",
                      onChange: handleSearch,
                      name: "institution",
                      className: "block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                    }
                  ) })
                ] })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "mt-4 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-2", children: /* @__PURE__ */ jsxs("div", { className: "col-span-2 flex items-center justify-end", children: [
                /* @__PURE__ */ jsx("p", { className: "mr-3 text-sm text-gray-500", children: `(${data.length ? data.length : 0} registros)` }),
                /* @__PURE__ */ jsx(ExcelReportButton, { data }),
                /* @__PURE__ */ jsx(
                  "button",
                  {
                    onClick: handleClean,
                    className: "rounded-md bg-indigo-600 px-6 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600",
                    children: "Limpiar"
                  }
                )
              ] }) })
            ] }) })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "inline-block min-w-full overflow-hidden rounded-lg shadow", children: /* @__PURE__ */ jsxs("table", { className: "w-full whitespace-no-wrap", children: [
            /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "border-b bg-gray-50 text-left text-xs font-semibold uppercase tracking-wide text-gray-500", children: [
              /* @__PURE__ */ jsx("th", { className: "border-b-2 border-gray-200 bg-gray-100 px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-600", children: "Institución" }),
              /* @__PURE__ */ jsx("th", { className: "border-b-2 border-gray-200 bg-gray-100 px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-600", children: "Nombre Financiamiento" }),
              /* @__PURE__ */ jsx("th", { className: "border-b-2 border-gray-200 bg-gray-100 px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-600 hidden sm:table-cell", children: "Fecha de Inicio" }),
              /* @__PURE__ */ jsx("th", { className: "border-b-2 border-gray-200 bg-gray-100 px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-600 hidden sm:table-cell", children: "Fecha de Fin" }),
              /* @__PURE__ */ jsx("th", { className: "border-b-2 border-gray-200 bg-gray-100 px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-600 hidden sm:table-cell", children: "Estado" }),
              /* @__PURE__ */ jsx("th", { className: "border-b-2 border-gray-200 bg-gray-100 px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-600", children: "Más" })
            ] }) }),
            /* @__PURE__ */ jsx("tbody", { children: data.map((financing) => /* @__PURE__ */ jsxs(
              "tr",
              {
                className: "text-gray-700",
                children: [
                  /* @__PURE__ */ jsx("td", { className: "border-b border-gray-200 bg-white px-5 py-5 text-sm", children: /* @__PURE__ */ jsx("p", { className: "text-gray-900 whitespace-no-wrap", children: financing.institution }) }),
                  /* @__PURE__ */ jsx("td", { className: "border-b border-gray-200 bg-white px-5 py-5 text-sm", children: /* @__PURE__ */ jsx("p", { className: "text-gray-900 whitespace-no-wrap", children: financing.name }) }),
                  /* @__PURE__ */ jsx("td", { className: "border-b border-gray-200 bg-white px-5 py-5 text-sm hidden sm:table-cell", children: /* @__PURE__ */ jsx("p", { className: "text-gray-900 whitespace-no-wrap", children: financing.start_date }) }),
                  /* @__PURE__ */ jsx("td", { className: "border-b border-gray-200 bg-white px-5 py-5 text-sm hidden sm:table-cell", children: /* @__PURE__ */ jsx("p", { className: "text-gray-900 whitespace-no-wrap", children: financing.end_date }) }),
                  /* @__PURE__ */ jsx("td", { className: "border-b border-gray-200 bg-white px-5 py-5 text-sm hidden sm:table-cell", children: /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "checkbox",
                      checked: financing.status == 1,
                      disabled: true,
                      className: "mr-1"
                    }
                  ) }),
                  /* @__PURE__ */ jsx("td", { className: "border-b border-gray-200 bg-white px-5 py-5 text-sm", children: /* @__PURE__ */ jsx(
                    Link,
                    {
                      className: "text-blue-600 underline whitespace-no-wrap hover:text-gray-900",
                      href: route("financing.show", { id: financing.id }),
                      children: "Información"
                    }
                  ) })
                ]
              },
              financing.id
            )) })
          ] }) })
        ] }) })
      ]
    }
  );
}
export {
  Index as default
};
